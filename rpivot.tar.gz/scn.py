
# Socket lib used for devloping netwok tools
import time
from socket import *
# optparse lib used for command line option features
from optparse import OptionParser
# Threading  lib used for running multiple threads in python
from threading import *


# Defining ConnScan Function
def connScan(tgtHost, tgtPort):
    try:
        #print 'try: %s %d' % (tgtHost, tgtPort)
        sock = socket(AF_INET, SOCK_STREAM)
        sock.connect((tgtHost, tgtPort))
        print '%s %d/tcp is Open' % (tgtHost, tgtPort)
    except Exception as ex:
        pass
    finally:
        sock.close()


# defing PortScan method
def portscan(tgtIP, tgtPorts):
    # here we are tying to get  ip from domain , if suppose user enters domain name instead of  host ip address
    # gethostbyname   is funtion which is used for get target ip from domain name

    # here we are defing timeout for a 1 sec
    setdefaulttimeout(1)
    #  creating for loop function  to get "tgtPort" one by one from "tgtPorts"
    for tgtPort in tgtPorts:
        # Creating thread to run muliple process at a time
        t = Thread(target=connScan, args=(tgtIP, int(tgtPort)))

        t.start()



# Defining Main Function
def main():
    parser = OptionParser("Usage of Program:" + "-H <Target Host> -P <Target Port>")
    parser.add_option("-H", dest="tgthost", help="Target Host")
    parser.add_option("-P", dest="tgtport", help="Target Ports , Use(,)comma to seprate")

    (options, args) = parser.parse_args()
    ##Assigning values to the Variable
    tgtHost = options.tgthost
    tgtPorts = str(options.tgtport).split(',')
    # Checking host and port to return usage if  values are null
    if (tgtHost == None) | (tgtPorts[0] == None):
        print parser.usage
        exit(0)
    # Portscan funtion calling
    for line in open(tgtHost, 'rt'):
        portscan(line.strip(), tgtPorts)
        time.sleep(0.1)

if __name__ == '__main__':
    main()